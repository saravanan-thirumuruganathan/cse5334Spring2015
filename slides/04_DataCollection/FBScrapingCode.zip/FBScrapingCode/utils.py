import ConfigParser
import time
import sys
import os
from datetime import datetime
from urlparse import parse_qs, urlsplit, urlunsplit
import MySQLdb as mdb


def loginToFacebook(driver, userName, password):
	driver.get('https://www.facebook.com/');
	time.sleep(5) 

	emailTextBox = driver.find_element_by_id('email')
	emailTextBox.send_keys(userName)
	passwordTextBox = driver.find_element_by_id('pass')
	passwordTextBox.send_keys(password)
	passwordTextBox.submit()


def getDriver(driverName, webdriver):
	driver = None 
	if driverName == "Chrome":
		driver = webdriver.Chrome()  
	if driverName == "Firefox":
		driver = webdriver.Firefox()  
	if driverName == "PhantomJS":
		driver = webdriver.PhantomJS()
	if driver == None:
		print "Please enter a valid driver name in config"
		sys.exit(1)
	return driver

def readConfig(fileName):
	settings = {}
	config = ConfigParser.ConfigParser()
	config.optionxform = str
	config.read(fileName)
	for name, value in config.items('Main'):
		settings[name] = value 
	return settings

def logToFile(logFileName, header, content):
	f = open(logFileName, 'a')
	f.write(header + " : " +  content + "\n")
	f.close()


def mapFileToFunction(fileName, fnName, opnDescription, logFileName, waitAfter=100):
	lines = open(fileName).readlines()
	count = 0
	for line in lines:
		count = count + 1
		if count % waitAfter == 0:
			time.sleep(300)
		try:
			line = line.strip()
			curTime = str(datetime.now())
			print "[" + curTime + "] Processing ", line 
			logToFile(logFileName, "[" + curTime + "] Info:" , "Processing " + line)
			fnName(line)
		except Exception as ex:
			logToFile(logFileName, "Exception:" + opnDescription + ":" + line + ":", str(ex))

def getPageNameFromUrl(pageUrl):
	pageUrl = pageUrl.replace("https://www.facebook.com/pages/", "")
	pageName = pageUrl.split("/")[0]
	return pageName

def getGroupNameFromUrl(groupUrl):
	groupName = groupUrl.replace("https://www.facebook.com/groups/", "")
	groupName = groupName.replace("/", "")
	return groupName 

def getProfileIDFromUrl(profileUrl):
	profileID = profileUrl.replace("https://www.facebook.com/", "")
	profileID = profileID.replace("profile.php?id=", "")
	profileID = profileID.replace("/", "")
	return profileID

def isProfileAllNumber(profileID):
	return profileID.isdigit()

def createDirIfNecessary(dirName):
	if not os.path.exists(dirName):
		os.makedirs(dirName)


#Useful to remove tracking params from urls : 
#	I/p : https://www.facebook.com/pages/Enders-Game/108178452537550?fb_action_ids=10100668219739081&fb_action_types=books.reads&fb_source=other_multiline&action_object_map=%5B108178452537550%5D&action_type_map=%5B%22books.reads%22%5D&action_ref_map=%5B%5D&fb_collection_id=14
#	O/p : https://www.facebook.com/pages/Enders-Game/108178452537550
def stripParamsFromUrl(url):
	scheme, netloc, path, query_string, fragment = urlsplit(url)
	return urlunsplit((scheme, netloc, path, '', ''))

def getUrlForFacebookTab(url, category):
	categories = ["about", "books", "friends", "games", "groups", "likes", "movies", "music", "photos_albums" , "tv"]
	if category not in categories:
		raise ValueError("Invalid category for getUrlForFacebookTab")

	if url[-1] != "/":
		url = url + "/" 

	if url.find("profile.php") >= 0:
		url = url + "&sk=" + category
	else:
		url = url + category 
	return url

def connectToDB():
        try:
                con = mdb.connect('server', 'username', 'pwd', 'dbName', charset='utf8');
                cur = con.cursor()
                cur.execute("set names utf8;")
        except mdb.Error, e:
                print "Error %d: %s" % (e.args[0],e.args[1])
                sys.exit(1)
        return con, cur

def updateStatus(con, cur, profileUrl, logFileName):
	profileID = getProfileIDFromUrl(profileUrl)
        try:
		cur.execute ("UPDATE profileTbl SET processed='Y' WHERE uid='%s' " % (profileID))
        	con.commit()
        except mdb.Error, e:
		logToFile(logFileName, "Exception:SaveToMySql" + ":" + profileUrl+ ":", str(e.args[0]) + " : " + str(e.args[1]))


