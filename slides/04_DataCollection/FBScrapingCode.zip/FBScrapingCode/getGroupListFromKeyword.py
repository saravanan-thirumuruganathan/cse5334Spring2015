import time
import selenium.webdriver
import sys
import utils 
import json


def getTopGroupsForKeyword(searchQuery):
	global driver, settings, logFileName
	global clickWaitTime
	driver.get("https://www.facebook.com/search/results.php?type=groups&q="+searchQuery);
	len1 = len(driver.find_elements_by_css_selector("div.instant_search_title.fsl.fwb.fcb > a"))
	while True:
		try :
			linkToClick = driver.find_element_by_css_selector("a.pam.uiBoxLightblue.uiMorePagerPrimary")
			linkToClick.click()
			time.sleep(clickWaitTime)
			len2 = len(driver.find_elements_by_css_selector("div.instant_search_title.fsl.fwb.fcb > a"))
			if len1 == len2:
				break
		except selenium.common.exceptions.ElementNotVisibleException:
			time.sleep(5)
		except selenium.common.exceptions.NoSuchElementException:
			break 
		except Exception as ex:
			utils.logToFile(logFileName, "Exception:GroupSearch:" + searchQuery + ":", str(ex))
			break

	try :
		numGroups = len(driver.find_elements_by_css_selector("div.instant_search_title.fsl.fwb.fcb > a"))
		nameOfGroup = driver.find_elements_by_css_selector("div.instant_search_title.fsl.fwb.fcb > a")
		numberOfMembers = driver.find_elements_by_css_selector("div.mts.detailedsearch_actions > a")
		groupStatus = driver.find_elements_by_css_selector("div.pls > div.fsm.fwn.fcg")
	except Exception as ex:
		utils.logToFile(logFileName, "Exception:GroupSearch:" + searchQuery + ":", str(ex))

	dirName = "db/keywordToGroup"
	utils.createDirIfNecessary(dirName)
	f = open(dirName + "/" + searchQuery + ".txt",'w')

	count = 0
	for i in range(len(nameOfGroup)):
		try:
			if groupStatus[i].text.split()[0] == "Open":
				count += 1
				name = nameOfGroup[i].get_attribute("text")
				url =  nameOfGroup[i].get_attribute("href")
				groupId = url.replace("https://www.facebook.com/groups/","").replace("/","")
				numMembers = numberOfMembers[i].get_attribute("text").split()[0]
				dictToWrite = {"ID" : groupId, "Name" : name, "URL" : url, "NumMembers" : numMembers}
				strToWrite = json.dumps(dictToWrite)
				f.write(strToWrite + "\n")
		except Exception as ex:
			utils.logToFile(logFileName, "Exception:GroupSearch:" + searchQuery + ":", str(ex))
	f.close()
	utils.logToFile(logFileName, "Info:GroupSearch:"+searchQuery+":" , "Got " + str(count) + " groups")

if len(sys.argv) == 1:
	print "Please enter a config file name"
	sys.exit(1)

settings = utils.readConfig(sys.argv[1])
logFileName = settings['logFileName']
clickWaitTime = int(settings['clickWaitTime'])
driver = utils.getDriver(settings['driverName'], selenium.webdriver)
utils.loginToFacebook(driver, settings['userName'], settings['password'])

utils.mapFileToFunction(sys.argv[2], getTopGroupsForKeyword, "GroupSearch", logFileName)
