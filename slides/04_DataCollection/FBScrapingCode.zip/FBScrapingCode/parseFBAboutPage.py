import time                                                                          
import selenium                                                                      
import selenium.webdriver                                                            
import sys                                                                           
import utils                                                                         
import json                                   

def getProfileDtls(driver, profileUrl, logFileName):   

	urlToGet = utils.getUrlForFacebookTab(profileUrl, "about")
	driver.get(urlToGet)

	profileDtls = {}

	# click See All in About Page
	linkClick = driver.find_element_by_css_selector("a._3t3")
	linkClick.click()

	#A hack - some times we get not attached to DOM error
	# 	Reloading the page seems to solve the issue
	currentUrl = driver.current_url
	driver.get(currentUrl)



	# Basic Information
	# =================================================================================
	try:
		aboutPagelet = driver.find_element_by_css_selector("#pagelet_timeline_medley_info > div[id^='collection_wrapper']")
		basicInfoLink = aboutPagelet.find_element_by_css_selector("#pagelet_basic")
		header = basicInfoLink.find_elements_by_css_selector("table.uiInfoTable.profileInfoTable.uiInfoTableFixed > tbody > tr > th")
		values = basicInfoLink.find_elements_by_css_selector("table.uiInfoTable.profileInfoTable.uiInfoTableFixed > tbody > tr > td")

		for index in range(len(header)):
			profileDtls[ header[index].text ] = values[index].text
	except Exception as ex:
		utils.logToFile(logFileName, "Exception:Profile_BasicInfo:" + urlToGet + ":", str(ex))



	# Living Information
	# =================================================================================
	try:
		liveLink = driver.find_element_by_css_selector("#pagelet_hometown")
		valueArr = liveLink.find_elements_by_css_selector("div.fsl.fwb.fcb > a")
		headerArr = liveLink.find_elements_by_css_selector("div.aboutSubtitle")
			
		for index in range(len(valueArr)):
			profileDtls[ headerArr[index].text ] = {
						"Name" : valueArr[index].text ,
						"URL"  : valueArr[index].get_attribute("href")
						}
	except Exception as ex:
		utils.logToFile(logFileName, "Exception:Profile_LivingInfo:" + urlToGet + ":", str(ex))


	# Contact Information
	# =================================================================================
	try:
		contactInformationLink = driver.find_element_by_css_selector("#pagelet_contact")
		header = contactInformationLink.find_elements_by_css_selector("table.uiInfoTable.profileInfoTable.uiInfoTableFixed > tbody > tr > th")
		values = contactInformationLink.find_elements_by_css_selector("table.uiInfoTable.profileInfoTable.uiInfoTableFixed > tbody > tr > td")

		for index in range(len(header)):
			profileDtls[ header[index].text ] = values[index].text
	except Exception as ex:
		utils.logToFile(logFileName, "Exception:Profile_ContactInfo:" + urlToGet + ":", str(ex))



	# Work & Education
	# ================================================================================= 
	try:
		workEduLink = driver.find_element_by_css_selector("#pagelet_eduwork")
		experienceArr = workEduLink.find_elements_by_css_selector("div.experienceContent")

		eduWorkDtls = [] 
		for experience in experienceArr:
			company = experience.find_element_by_class_name("experienceTitle").text
			body = experience.find_element_by_class_name("experienceBody").text
			eduWorkDtls.append( {"Organization" : company, "Details" : body} )

		profileDtls["EduWork"] = eduWorkDtls

	except Exception as ex:
		utils.logToFile(logFileName, "Exception:Profile_WorkEducation:" + urlToGet + ":", str(ex))


	# Relationship & Family
	# =================================================================================
	try:
		familyLink = driver.find_element_by_css_selector("#pagelet_relationships")
		valueArr = familyLink.find_elements_by_css_selector("div.fsl.fwb.fcb > a")
		headerArr = familyLink.find_elements_by_css_selector("div.aboutSubtitle")

		familyDtls = []
		for index in range(len(valueArr)):
			familyDtls.append( {
								"Relation" 	: headerArr[index].text, 
								"Name"		: valueArr[index].text,
								"URL"		: valueArr[index].get_attribute("href")
							})
		profileDtls["RelationshipFamily"] = familyDtls

	except Exception as ex:
		utils.logToFile(logFileName, "Exception:Profile_WorkEducation:" + urlToGet + ":", str(ex))

	print profileDtls
	return profileDtls
