fbTabSettings = {}

bookDtls_ = {}
bookDtls_["categoryName"] = "books"
bookDtls_["pageletCssSelector"] = "#pagelet_timeline_medley_books > div[id^='collection_wrapper']"
bookDtls_["tabItemsCssSelector"] = "div._gx6._agv > a"
bookDtls_["tabItemTypeCssSelector"] = "div.fsm.fwn.fcg" 
fbTabSettings["books"] = bookDtls_


friendsDtls_ = {}
friendsDtls_["categoryName"] = "friends"
friendsDtls_["pageletCssSelector"] = "#pagelet_timeline_medley_friends > div[id^='collection_wrapper']"
friendsDtls_["tabItemsCssSelector"] = "div.fsl.fwb.fcb > a"
friendsDtls_["tabItemTypeCssSelector"] = None
fbTabSettings["friends"] = friendsDtls_


gameDtls_ = {}
gameDtls_["categoryName"] = "games"
gameDtls_["pageletCssSelector"] = "#pagelet_timeline_medley_games > div[id^='collection_wrapper']"
gameDtls_["tabItemsCssSelector"] = "div._gx6._agv > a"
gameDtls_["tabItemTypeCssSelector"] ="div.fsm.fwn.fcg"
fbTabSettings["games"] = gameDtls_


groupDtls_ = {}
groupDtls_["categoryName"] = "groups"
groupDtls_["pageletCssSelector"] = "#pagelet_timeline_medley_groups > div[id^='collection_wrapper']"
groupDtls_["tabItemsCssSelector"] = "div.mtm > div.mbs.fwb > a"
groupDtls_["tabItemTypeCssSelector"] = "div.mtm > div.mbs.fcg"
fbTabSettings["groups"] = groupDtls_


likeDtls_ = {}
likeDtls_["categoryName"] = "likes"
likeDtls_["pageletCssSelector"] = "#pagelet_timeline_medley_likes > div[id^='collection_wrapper']"
likeDtls_["tabItemsCssSelector"] = "div._gx6._agv > a"
likeDtls_["tabItemTypeCssSelector"] = None
fbTabSettings["likes"] = likeDtls_


movieDtls_ = {}
movieDtls_["categoryName"] = "movies"
movieDtls_["pageletCssSelector"] = "#pagelet_timeline_medley_movies > div[id^='collection_wrapper']"
movieDtls_["tabItemsCssSelector"] = "div._gx6._agv > a"
movieDtls_["tabItemTypeCssSelector"] = "div.fsm.fwn.fcg"
fbTabSettings["movies"] = movieDtls_


musicDtls_ = {}
musicDtls_["categoryName"] = "music"
musicDtls_["pageletCssSelector"] = "#pagelet_timeline_medley_music > div[id^='collection_wrapper']"
musicDtls_["tabItemsCssSelector"] = "div._gx6._agv > a"
musicDtls_["tabItemTypeCssSelector"] = "div.fsm.fwn.fcg"
fbTabSettings["music"] = musicDtls_



photoDtls_ = {}
photoDtls_["categoryName"] = "photos_albums"
photoDtls_["pageletCssSelector"] = "#pagelet_timeline_medley_photos > div[id^='collection_wrapper']"
photoDtls_["tabItemsCssSelector"] = "div.photoText > a.photoTextTitle"
photoDtls_["tabItemTypeCssSelector"] = "div.photoText > div.photoTextSubtitle.fsm.fwn.fcg"
fbTabSettings["photos_albums"] = photoDtls_


tvDtls_ = {}
tvDtls_["categoryName"] = "tv"
tvDtls_["pageletCssSelector"] = "#pagelet_timeline_medley_tv > div[id^='collection_wrapper']"
tvDtls_["tabItemsCssSelector"] = "div._gx6._agv > a"
tvDtls_["tabItemTypeCssSelector"] = "div.fsm.fwn.fcg"
fbTabSettings["tv"] = tvDtls_


