import time
import selenium.webdriver
import sys
import utils 
import json


def getGroupMembersOfOpenGroup(groupUrl):
	global driver, settings, logFileName
	global clickWaitTime

	groupName = utils.getGroupNameFromUrl(groupUrl)
	groupUrl = groupUrl + "members/"

	driver.get(groupUrl)

	while True :
		try :
			linkToClick = driver.find_element_by_css_selector("a.pam.uiBoxLightblue.uiMorePagerPrimary")
			linkToClick.click()
			time.sleep(clickWaitTime)

		except selenium.common.exceptions.ElementNotVisibleException:
			time.sleep(5)
		except selenium.common.exceptions.NoSuchElementException:
			break 
		except Exception as ex:
			utils.logToFile(logFileName, "Exception:GroupToMembers:" + searchQuery + ":", str(ex))
			break

	try:

		dirName = "db/GroupToMembers"
		utils.createDirIfNecessary(dirName)
		f = open(dirName + "/" + "Members_" + groupName + ".txt",'w')

		member = driver.find_elements_by_css_selector("div.fsl.fwb.fcb > a")
	except Exception as ex:
		utils.logToFile(logFileName, "Exception:GroupToMembers:" + groupName + ":", str(ex))

	for i in range(len(member)):
		try:
			profileName = member[i].get_attribute("text")
			profileUrl = member[i].get_attribute("href")
			profileID = utils.getProfileIDFromUrl(profileUrl)
			isProfileInt = utils.isProfileAllNumber(profileID)
			dictToWrite = {"ID" : profileID, "URL" : profileUrl , "Name" : profileName, "ProfileInt" : isProfileInt}
			strToWrite = json.dumps(dictToWrite)
			f.write(strToWrite + "\n")
		except Exception as ex:
			utils.logToFile(logFileName, "Exception:GroupToMembers:" + groupName + ":", str(ex))
	f.close()

if len(sys.argv) == 1:
	print "Please enter a config file and a seed file name"
	sys.exit(1)

settings = utils.readConfig(sys.argv[1])
logFileName = settings['logFileName']
clickWaitTime = int(settings['clickWaitTime'])
driver = utils.getDriver(settings['driverName'], selenium.webdriver)
utils.loginToFacebook(driver, settings['userName'], settings['password'])
utils.mapFileToFunction(sys.argv[2], getGroupMembersOfOpenGroup, "GroupToMembers", logFileName)
