import time
import selenium.webdriver
import sys
import utils 
import json

def getRelatedPage(pageUrl):
	global driver, settings, logFileName
	global clickWaitTime

	origPageName = utils.getPageNameFromUrl(pageUrl)
	
	driver.get(pageUrl)

	linkToClick = driver.find_element_by_css_selector("div._438 > a")
	linkToClick.click()
	time.sleep(15)

	while True :
			try :                                                      
				linkClick = driver.find_element_by_css_selector("a.pam.uiBoxLightblue.uiMorePagerPrimary")
				linkClick.click()
				time.sleep(15)
			except selenium.common.exceptions.ElementNotVisibleException:
				time.sleep(5)
			except selenium.common.exceptions.NoSuchElementException:
				break

	try:
		nameOfPage = driver.find_elements_by_css_selector("div.fsl.fwb.fcb > a")
	except Exception as ex:                                                          
		utils.logToFile(logFileName, "Exception:RelatedPages:" + searchQuery + ":", str(ex))

	dirName = "db/PageToRelPage"
	utils.createDirIfNecessary(dirName)
	f = open(dirName + "/" + "RelPage_" + origPageName + ".txt",'w')
	for i in range(len(nameOfPage)):
		try:
			relatedPageName = nameOfPage[i].get_attribute("text")
			relatedPageUrl = nameOfPage[i].get_attribute("href")
			dictToWrite = {"PageName" : relatedPageName, "URL" : relatedPageUrl, "OrigPage" : origPageName}
			strToWrite = json.dumps(dictToWrite)
			f.write(strToWrite + "\n")
		except Exception as ex:                                                          
			utils.logToFile(logFileName, "Exception:RelatedPages:" + searchQuery + ":", str(ex))
	f.close()


if len(sys.argv) == 1:
	print "Please enter a config file name and an input seed file"
	sys.exit(1)

settings = utils.readConfig(sys.argv[1])
logFileName = settings['logFileName']
clickWaitTime = int(settings['clickWaitTime'])
driver = utils.getDriver(settings['driverName'], selenium.webdriver)
utils.loginToFacebook(driver, settings['userName'], settings['password'])

utils.mapFileToFunction(sys.argv[2], getRelatedPage, "RelatedPages", logFileName)


