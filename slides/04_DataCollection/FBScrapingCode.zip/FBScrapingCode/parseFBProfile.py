import time                                                                          
import selenium
import selenium.webdriver                                                            
import sys                                                                           
import utils                                                                         
import json
from fbTabCssSelectors import *
from parseFBAboutPage import *

from pymongo import MongoClient
import MySQLdb as mdb


def getTabContents(driver, profileUrl, categoryName, dictOfSettings):
	pageletCssSelector		= dictOfSettings[categoryName]["pageletCssSelector"] 
	tabItemsCssSelector		= dictOfSettings[categoryName]["tabItemsCssSelector"] 
	tabItemTypeCssSelector	= dictOfSettings[categoryName]["tabItemTypeCssSelector"] 

	global logFileName
	try:
		urlToGet = utils.getUrlForFacebookTab(profileUrl, categoryName)
		driver.get(urlToGet)                                 
		pagelet = driver.find_element_by_css_selector(pageletCssSelector)
		len1 = len(pagelet.find_elements_by_css_selector(tabItemsCssSelector)) 
	except Exception as ex:
		utils.logToFile(logFileName, "Exception:" + categoryName + ":" + urlToGet + ":", str(ex))
		return [] 


	# Scrol downpage till you get everything
	while True :
		try :
			driver.execute_script("window.scrollBy(0,10000)", "")
			time.sleep(5)
			len2  = len(bookPagelet.find_elements_by_css_selector(tabItemsCssSelector))
			if len1 == len2:
				break
			len1 = len2
		except Exception as ex:
			break


	tabContents = []
	try:
		allItems = pagelet.find_elements_by_css_selector(tabItemsCssSelector)
		if tabItemTypeCssSelector is not None:
			allItemType = pagelet.find_elements_by_css_selector(tabItemTypeCssSelector)

		if len(allItems) == 0 :
			return []
		else:
			for i in range(len(allItems)):
				name = allItems[i].get_attribute("text")
				url = utils.stripParamsFromUrl(allItems[i].get_attribute("href"))
				itemType = ""
				if tabItemTypeCssSelector is not None:
					itemType = allItemType[i].text         
				tabContents.append( {"Name" : name,
								 "URL"  : url,
								 "Type" : itemType 
								 })
	except Exception as ex:
		utils.logToFile(logFileName, "Exception:" + categoryName + ":" + urlToGet + ":", str(ex))
	return tabContents 

def getDtlsFromFBProfile(profileUrl):
	global driver, settings, logFileName 

	facebookTabs = ["books", "friends", "games", "groups", "likes", "movies", "music", "photos_albums" , "tv"]

	fbProfileDts = {}

	fbProfileDts["_id"] = utils.getProfileIDFromUrl(profileUrl)
	fbProfileDts["ProfileID"] = utils.getProfileIDFromUrl(profileUrl)
	fbProfileDts["ProfileURL"] = profileUrl 

	try:
		#print "Handling about page"
		aboutPageDtls = getProfileDtls(driver, profileUrl, logFileName)
		fbProfileDts["About"] = aboutPageDtls
	except Exception as ex:
		utils.logToFile(logFileName, "Exception:AboutPage" +  ":" + profileUrl + ":", str(ex))

	for tabName in facebookTabs:
		try:
			#print "Handling " , tabName
			tabDtls = getTabContents(driver, profileUrl, tabName, fbTabSettings)
			fbProfileDts[tabName] = tabDtls
		except Exception as ex:
			utils.logToFile(logFileName, "Exception:" + categoryName + ":" + profileUrl + ":", str(ex))

	return fbProfileDts

def persistProfile(collection, profileDtls, profileUrl, logFileName):
	try:
		collection.insert(profileDtls)
		#utils.updateStatus(con, cur, profileUrl, logFileName)
	except Exception as ex:
		utils.logToFile(logFileName, "Exception:SaveToMongo" + ":" + profileUrl+ ":", str(ex))

settings = utils.readConfig(sys.argv[1])                                             
logFileName = settings['logFileName']                                                
clickWaitTime = int(settings['clickWaitTime'])                                       
driver = utils.getDriver(settings['driverName'], selenium.webdriver)                 
utils.loginToFacebook(driver, settings['userName'], settings['password'])            

client = MongoClient()
db = client['fbprojdb']
collection = db['fbprojtbl']

#con, cur = utils.connectToDB()

profiles = [profile.strip() for profile in open(sys.argv[2]).readlines()]
for profileUrl in profiles:
	profileUrl = profileUrl.strip()
	profileDtls = getDtlsFromFBProfile(profileUrl)
	persistProfile(collection, profileDtls, profileUrl, logFileName)

