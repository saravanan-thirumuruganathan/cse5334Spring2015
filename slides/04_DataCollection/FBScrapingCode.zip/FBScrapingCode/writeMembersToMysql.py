import MySQLdb as mdb
import sys
import json
import glob
import sys

def getProfileIDFromUrl(profileUrl):
	profileID = profileUrl.replace("https://www.facebook.com", "")
	profileID = profileID.replace("profile.php?id=", "")
	profileID = profileID.replace("/", "")
	return profileID


def convertToDBFormat(jsonData):
	jsonData = json.loads(jsonData)
	dbData = {}
	dbData["uid"] = getProfileIDFromUrl(jsonData["URL"])
	dbData["url"] = jsonData["URL"]
	dbData["processed"] = "N"
	dbData["type"] = "N"
	if jsonData["URL"].find("profile.php") > -1:
		dbData["type"] = "O"
	dbData["name"] = jsonData["Name"].replace("profile.php?id=", "") #.decode('utf8')
	return dbData

def connectToDB():
	try:
		con = mdb.connect('host', 'uname', 'pwd', 'dbName', charset='utf8');
		cur = con.cursor()
		cur.execute("set names utf8;")
	except mdb.Error, e:
		print "Error %d: %s" % (e.args[0],e.args[1])
		sys.exit(1)
	return con, cur 

def insertToDB(con, cur,row, fileName):
	row = convertToDBFormat(row) 

	try:
		#sqlToExecute = "INSERT INTO 'profileTbl' ('uid', 'url', 'processed', 'type', 'name')  VALUES ( %(uid)s, %(url)s, %(processed)s, %(type)s, %(name)s) "
		sqlToExecute = "INSERT INTO profileTbl (uid, url, processed, type, name)  VALUES ( %s, %s, %s, %s, %s) "
		#print sqlToExecute % (row["uid"], row["url"], row["processed"], row["type"], row["name"])
		cur.executemany(sqlToExecute, [(row["uid"], row["url"], row["processed"], row["type"], row["name"])])
	except mdb.Error, e:
		print "Error while inserting " , fileName, " when writing ", row 
		print "Error %d: %s" % (e.args[0],e.args[1])
		
	con.commit()


con, cur = connectToDB()

for fileName in glob.glob(sys.argv[1] + "/*.txt"):
	print "-----------------handling ", fileName, "------------------"
	lines = open(fileName, "r").readlines()
	for line in lines:
		insertToDB(con, cur, line, fileName) 
